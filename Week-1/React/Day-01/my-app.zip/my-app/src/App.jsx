import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import MainHeader from './components/MainHeader'
import MainCounter from './components/MainCounter'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <div>
        <MainHeader/>
      </div>
      <div>
        <MainCounter/>
      </div>
      <div className='infomation'>
        <table>
          <tr>
            <th>
              Profile
            </th>
            <th>
              Skill & Hobbies
            </th>
          </tr>
          <tr>
            <td>Name: Harshal Yadav </td>
            <td>• React.js </td>
          </tr>
          <tr>
            <td>Location: Pune, India </td>
            <td>• JavaScript </td>
          </tr>
          <tr>
            <td>Profession: Developer </td>
            <td>• JavaScript </td>
          </tr>
          <tr>
            <td>Email: harshalyadav@gmail.com </td>
            <td> • Reading Blogs  </td>
          </tr>
        </table>

      </div>
    </>
  )
}

export default App
